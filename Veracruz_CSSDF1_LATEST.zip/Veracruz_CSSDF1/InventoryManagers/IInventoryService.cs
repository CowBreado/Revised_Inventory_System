﻿using InventoryModels;

namespace InventoryManagers
{
    public interface IInventoryService
    {
        IEnumerable<Food> GetAllFood ();
        Food GetFoodById(int id);

        void AddFood(Food food);

        void UpdateFood(int id, Food food);

        void DeleteFood(int id);

        //Update price or something, to be updated...

    }
}
