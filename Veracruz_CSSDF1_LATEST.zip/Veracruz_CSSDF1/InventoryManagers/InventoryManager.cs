﻿using InventoryModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagers
{
   public class InventoryManager : IInventoryService
   {
       //Cost variable is subject to deletion due to computation which could be: Price (PHP) =  Weight * Kg;
       private readonly List<Food> _foods = new List<Food>
       {
           new Food { Id = 1, Name = "Whole Poultry Chicken" , Type = "Chicken", Cost = 0, Weight = 2.0f, Quantity = 1 },
           new Food { Id = 3, Name = "Tuna Belly" , Type = "Fish", Cost = 0, Weight = 3.0f, Quantity = 3 }
       };

       public IEnumerable<Food> GetAllFood()
       {
           return _foods;
       }

       public Food GetFoodById(int id)
       {
           return _foods.FirstOrDefault(x => x.Id == id);
       }
       public void AddFood(Food food)
       {
            _foods.Add(food);
       }

        public void UpdateFood(int id, Food food)
        {
            var existingFood = _foods.FirstOrDefault(x => x.Id == id);
            if (existingFood != null)
            {
                existingFood.Quantity = food.Quantity;
                existingFood.Cost = food.Cost;
                //Name maybe add spoiled: spoiled chicken lol?
                existingFood.Name = food.Name;
            }
        }
        
        public void DeleteFood(int id)
        {
            var food = _foods.FirstOrDefault(s => s.Id == id);
            if (food != null)
            {
                _foods.Remove(food);
            }
        }
    }
}
