﻿namespace InventoryModels
{
    public class Food
    {


        //Id for: 1 - Chicken, 2 - Beef, 3 - Fish, 4 - Vegetable, - 5 Canned Goods idk
        public int Id { get; set; }

        //Name for: Chicken, Beef ....
        public string Name { get; set; }
        //Type for: Meat, Fish, Canned Goods, Vegetable
        public string Type { get; set; }

        //Cost for: 61.23 PHP, or maybe cost per kilo???
        public double Cost { get; set; }
        //Weight for: 23grams
        public float Weight { get; set; }
        //Quantity for: 1,2,3,5 pieces etc..
        public int Quantity { get; set; }



    }
}
