﻿using InventoryManagers;
using InventoryModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Veracruz_Inventory.Controllers
{

[Route("api/[controller]")]
[ApiController]
    public class InventoryControllers : ControllerBase
    {
            private readonly IInventoryService _inventoryService;
            public InventoryControllers(IInventoryService inventoryService)
            {
                _inventoryService = inventoryService;
            }

            [HttpGet]

            public ActionResult<IEnumerable<Food>> GetFoods()
            {
                return Ok(_inventoryService.GetAllFood());
            }


            [HttpGet("{id}")]
            public ActionResult<Food> GetFood(int id)
            {
                var food = _inventoryService.GetFoodById(id);
                if (food == null)
                {
                    return NotFound();
                }
                return Ok(food);
            }

            [HttpPost]

            public ActionResult AddFood(Food food)
            {
                _inventoryService.AddFood(food);
                return CreatedAtAction(nameof(GetFood), new { id = food.Id }, food);
            }

            [HttpPut("{id}")]
            public IActionResult UpdateFood(int id, Food food)
            {
                var existingFood = _inventoryService.GetFoodById(id);
                if (existingFood == null)
                {
                    return NotFound();
                }

                _inventoryService.UpdateFood(id, food);
                return NoContent();
            }

            [HttpDelete("{id}")]
            public IActionResult DeleteFood(int id)
            {
                var food = _inventoryService.GetFoodById(id);
                if (food == null)
                {
                    return NotFound();
                }
                _inventoryService.DeleteFood(id);
                return NoContent();
            }

        }
}

